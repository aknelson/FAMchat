<?php

$service_url = 'https://api.api.ai/v1/query';
$curl = curl_init($service_url);

$curl_post_data = array(
        'v' => '20170712',
        'query' => 'how much is a burger',
        'lang' => 'en',
        'sessionId' => 'e501c931-7cbe-4f35-a72d-95bd6d25fc4d',
        'timezone' => 'America/New_York'
);

$c = json_encode($curl_post_data);

curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    'Authorization:Bearer 47d76b58b1ea45589ad397b75ec61023',
    'Content-Type: application/json; charset=utf-8')
);

curl_setopt($curl, CURLOPT_AUTOREFERER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_HTTPPROXYTUNNEL, true);
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 0);

curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($curl, CURLOPT_POST, TRUE);
curl_setopt($curl, CURLOPT_POSTFIELDS, $c);


$curl_response = curl_exec($curl);

if ($curl_response === false) {
    $info = curl_getinfo($curl);
    curl_close($curl);
    die('error occured during curl exec. Additioanl info: ' . var_export($info));
}

curl_close($curl);
$decoded = json_decode($curl_response);
if (isset($decoded->response->status) && $decoded->response->status == 'ERROR') {
    die('error occured: ' . $decoded->response->errormessage);
}

echo 'response ok!';
echo '<br>';
echo "curl response ".$curl_response;
echo '<br>';

//var_export($decoded->response);

?>
 