<?php
header('Content-Type: application/json');
ob_start();

$json = file_get_contents('php://input'); 
$request = json_decode($json, true);
$action = $request["result"]["action"];
$parameters = $request["result"]["parameters"];
$activities = $parameters["activities"];
$department = $parameters["department"];
$courses = $parameters["courses"];
$services = $parameters["services"];
$faculty = $parameters["faculty"];
$noun = $parameters["noun"];
$query = $request["result"]["resolvedQuery"];


//connect to mongodb
  $m = new MongoClient();
//echo "Connection to database successfully";
   
     
//select a database
  $db = $m->mydb;

switch($action){
  case "studentclubs":{
        $departmentassociation = $parameters["departmentassociation"];
        $searchdocument = array();
        $searchdocument["title"] = "club";
      

      //echo "Database mydb selected";
        $collection = $db->club;
      //echo "Collection selected succsessfully";
    
        $newQuery = array("title" => $departmentassociation);
        $cursor = $collection->find($newQuery);
  

        $document = $cursor->getNext();
    
        if($cursor->hasNext())
           {
             $response = "The clubs are ".$document["clubName"];
          
                    while($cursor->hasNext())
                    {
                        
                        $document = $cursor->getNext();
                        
                        if(!($cursor->hasNext()))  
                            $response .= " and ".$document["clubName"];
                        else 
                            $response .= ", ".$document["clubName"];
                        
                    } 
           }
        else
           {
             $response = "The only club that I know of is ".$document["clubName"];
           }
            
    }// end of find clubs
    break;

  case "departmentLocation-action": {
    
        $searchdocument = array();

        $searchdocument["location"] = $department;   
      

      //echo "Database mydb selected";
        $collection = $db->department;
      //echo "Collection selected succsessfully";
    
        $newQuery = array('address.street' => 'Wanish Way');

        $cursor = $collection->find($newQuery);
      //iterate cursor to display title of documents
     
  
        $document = $cursor->getNext();
                
  
                $response = "The address is ".$document["address"]["number"]." ".$document["address"]["street"]."."; 
// //              Inserting Query into Query database  
//                 $collection = $db->query;
//                 $document = array( 
//                                   "query" => $query;
//                                  );
//                 $collection->insert($document);
            } break; //case-where
  
         
        
//    case "department-intent": {


// //              Inserting Query into Query databas  
// //                 $collection = $db->query;
// //                 $document = array( 
// //                                   "query" => $query;
// //                                  );
// //                 $collection->insert($document);
                  
               
//      }break;//case department-intent

    case "getlabhours":
    {
 


        $searchdocument = array();

        $searchdocument["lab hours"] = $department;   
      

      //echo "Database mydb selected";
        $collection = $db->department;
      //echo "Collection selected succsessfully";
    
        $newQuery = array('address.street' => 'Wanish Way');

        $cursor = $collection->find($newQuery);
      //iterate cursor to display title of documents
     
  
        $document = $cursor->getNext();

  
        $response = "The ".$department." are ".$document["lab hours"]; 
  
    }break;
  case "findClass": 
    {
        $courses = $parameters["courses"]; 
        $noun = $parameters["noun"];    
        $courseassociation = $parameters["courseassociation"];       
        $topic = $parameters["topic"];        
        
      
        $searchdocument = array();
        //select collection
        $collection = $db->courses;

         // user asks what are the credit hours 
        if($courseassociation == "credit hours"){
           //$searchdocument["crsHrs"] = $courses;

            $newQuery = array("crsID" => $courses);
            $cursor = $collection->find($newQuery);

            $document = $cursor->getNext();
            $response = "The course " .$courses. " in ".$document["term"]." is " .$document["crsHrs"]. " credit hours";

        }//if
       
        // user asks what are the prereqs
        elseif($courseassociation == "prerequisites"){
          //  $searchdocument["crsID"] = $courses;
            $newQuery = array("crsID" => $courses);
            $cursor = $collection->find($newQuery);    
            $document = $cursor->getNext();
            
             $document = $cursor->getNext();
            
            $response = "The prerequisities for ".$courses." in " .$document["term"]. " are ".$document["prereqs"].".";

        }//elseif
    
        // user asks who is the professor
        elseif($courseassociation == "professor"){
        $searchdocument = array();
        $searchdocument["crsID"] = $courses;
        $newQuery = array("crsID" => $courses);
        $cursor = $collection->find($newQuery);
  

        $document = $cursor->getNext();
 
        if($cursor->hasNext())
           {
                    while($cursor->hasNext())
                    {
                        $response = "The instructors are Professor ".$document["crsInstructor"];
                        
                        $document = $cursor->getNext();
                        
                        if(!($cursor->hasNext()))  
                            $response .= " and Professor ".$document["crsInstructor"];
                        else 
                            $response .= ", ".$document["crsInstructor"];
                        
                    } 
           }
        else
           {
             $response = "The instructor is Professor ".$document["crsInstructor"];
           }

        }//elseif
      //user asks does a course teach a topic or what course teaches a topic
      elseif($courseassociation = "teaches"){
        $searchdocument = array();
        $searchdocument["topic"] = $topic;
        $newQuery = array("topic" => $topic);
        $cursor = $collection->find($newQuery);
        $document = $cursor->getNext();
        
        $response = "A course that teaches that topic is " .$document["crsID"]. ".";
        
      }//elseif

      //user asks when a course is taught
//     }/elseif($courseassociation == "when"){
//         $searchdocument = array();
//         $searchdocument["crsID" ]$courses;
//         $newQue=  array("crsID"  $courses;
//         ca$cursor = $collectionf-find($newQuery);
//         $documen()t = $curso-rggetNext;
      
//          if($term == $document["term"]){
//         $response = .$courses. " in ".$document["term"]." is at " .$document["time"];
//         }//if
//         else
//         {
//           $response = "The data for that term is not available yet";
//        }//else

//        elseif($noun == "Is"){
//             $searchdocument["crsID"] = $courses;
//             $newQuery = array("crsID" => $courses);
//             $cursor = $collection->find($newQuery);
//             $document = $cursor->getNext();
//              if($cursor = $collection->find(array("crsID" => null))){
//                 $response = "Yes";
//             } 
//          else
//          {
//                 $response = "No";
//          } 
       }//elseif end of find class case
    break;
    case "findEvents":
       //user asks what events are happening
       {

        $searchdocument = array();

        $searchdocument["title"] = $activities;   
  
        
        $collection = $db->activities;
     //echo "Collection selected succsessfully";

        $newQuery = array("title" => $activities);
        $cursor = $collection->find($newQuery);
     
     //get first event
        $document = $cursor->getNext();
     
        if($cursor->hasNext())
           {
                    while($cursor->hasNext())
                    {
                        $response = "The events are ".$document["name"];
                        
                        $document = $cursor->getNext();
                        
                        if(!($cursor->hasNext()))  
                            $response .= " and ".$document["name"];
                        else 
                            $response .= ", ".$document["name"];                        
                    } 
           }
        else
           {
             $response = "The only event I know of is ".$document["name"];
           }
		    

    }break;
    
    case "academiccomplaint":{
         $firstname = $parameters["firstname"];
         $lastname = $parameters["lastname"];
         $faculty = $parameters["faculty"];
         $classification = $parameters["classification"];
         $term = $parameters["term"];
         $areaofconcern = $parameters["areaofconcern"];
         $description = $parameters["description"];
         $attempttoresolve = $parameters["attempttoresolve"];

    
        $collection = $db->complaintform;
      
        $document = array(
            "firstname" => $firstname,
            "lastname" => $lastname,
            "faculty" => $faculty,
            "classification" => $classification,
            "term" => $term,
            "areaofconcern" => $areaofconcern,
            "description" => $description,
            "attempttoresolve" => $attempttoresolve
            );
    
           $collection->insert($document);

           $response = "Your academic complaint has been added.";
            
    }//end of academic complaint case
      break;
    case "joinclub":{ 
    $clubname = $parameters["clubs"];
    $firstname = $parameters["firstname"];
    $lastname = $parameters["lastname"];
    $email = $parameters["email"];
    $classification = $parameters["classification"];
       
       //select collection
        $collection = $db->clubmembers;

        //create a document
        $document = array(
           "clubName" => $clubname, 
           "FirstName" => $firstname,
           "LastName" => $lastname,
           "classification" => $classification,
           "email" => $email
        );

       //insert document
       $collection->insert($document);

        $searchdocument = array();
        if($searchdocument["firstName"] = $firstname && $searchdocument["clubName"] = $clubname)
           $response = "You have been added to $clubname succesfully.";
        else
           $response = "Hmm something seems to have went wrong. Lets try again.";
    }//end of join club case
        
    break;  
    
        case "scholarship-action":
     //user asks about scholarships
    {

        $searchdocument = array();

        $searchdocument["title"] = $scholarships;   
  
        
        $collection = $db->scholarships;
     //echo "Collection selected succsessfully";

        $newQuery = array("title" => $scholarships);
        $cursor = $collection->find($newQuery);
     
     //get first scholarship
        $document = $cursor->getNext();
     
        if($cursor->hasNext())
           {
                    while($cursor->hasNext())
                    {
                        $response = "The scolarships are ".$document["name"];
                        
                        $document = $cursor->getNext();
                        
                        if(!($cursor->hasNext()))  
                            $response .= " and ".$document["name"];
                        else 
                            $response .= ", ".$document["name"];                        
                    } 
           }
        else
           {
             $response = "The only scholarship that I know of is the ".$document["name"];
           }
		    

    }break;
    
    case "internship-action":
    //user asks about internships
    {

        $searchdocument = array();

        $searchdocument["title"] = $internships;   
  
        
        $collection = $db->internships;
     //echo "Collection selected succsessfully";

        $newQuery = array("title" => $internships);
        $cursor = $collection->find($newQuery);
     
     //get first internship
        $document = $cursor->getNext();
     
        if($cursor->hasNext())
           {
                    while($cursor->hasNext())
                    {
                        $response = "The internships are ".$document["company"];
                        
                        $document = $cursor->getNext();
                        
                        if(!($cursor->hasNext()))  
                            $response .= " and ".$document["company"];
                        else 
                            $response .= ", ".$document["company"];                        
                    } 
           }
        else
           {
             $response = "The only internship that I know of is the ".$document["company"];
           }
		    

    }break;
    
       case "people":
        {
        $faculty = $parameters["faculty"];
        $noun = $parameters["noun"];
        $facultyassociation = $parameters["facultyassociation"];        
        $collection = $db->faculty;

        //user asks who is the chairman
        if($facultyassociation == "Chairperson"){
            $searchdocument = array();
            $searchdocument["title"] = $facultyassociation;
            $newQuery = array("title" => $facultyassociation);
            $cursor = $collection->find($newQuery);      
            $document = $cursor->getNext();

            $response = "The chairperson is " .$document["name"];

        }//chairperson
          
          //user asks who are the systems administartors
        elseif($facultyassociation == "System Administrator"){
            $searchdocument = array();
            $searchdocument["title"] = $facultyassociation;
            $newQuery = array("title" => $facultyassociation);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();   

         if($cursor->hasNext())
           {
                     $response = "The system's administrators are " .$document["name"]. "."; 
                    while($cursor->hasNext())
                    {
                        
                        $document = $cursor->getNext();
                        
                        if(!($cursor->hasNext()))  
                            $response .= " and ".$document["name"]. "";
                        else 
                            $response .= ", ".$document["name"]. "";                        
                    } 
           }
        else
           {
             $response = "The system's administrators is " .$document["name"]. "."; 
           }


        }//admin
         //user asks who is the secretary or office manager
        elseif($facultyassociation == "Office Manager"){
            $searchdocument = array();
            $searchdocument["title"] = $facultyassociation;
            $newQuery = array("title" => $facultyassociation);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();      
            $response = "The office manager is ".$document["name"]. "";
        }//office manager

        //user asks where is someones office
        elseif($noun == "where"){
            $searchdocument = array();
            $searchdocument["name"] = $faculty;
            $newQuery = array("name" => $faculty);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();
            $response = $faculty."'s office is ".$document["location"]. ".";

        }//where if office
          
      //      user asks what is someones research
  
           elseif($facultyassociation == "research"){
            $searchdocument["name"] = $faculty;
            $newQuery = array("name" => $faculty);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();
            $response = $faculty."'s research revolves around ".$document["research"]. ".";   
        }// where is research
           
    }//end of people case
    break;
   
  case "officehours":
      //user asks for office hours of specific professor
      {
    $collection = $db->faculty;
    
    $faculty = $parameters["faculty"];
    
          if($facultyassociation = "office hours"){
            $searchdocument = array();
            $searchdocument["name"] = $faculty;
            $newQuery = array("name" => $faculty);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();           
            $response = $faculty."'s office hours are ".$document["hours"]["day"]. " at ".$document["hours"]["time"]. ".";


                    }//if 

  }//officehours
      
        break; 
      
  case "department-intent":{
        
        $collection = $db->department;
    
         $departmentassociation = $parameters["departmentassociation"];
         $clubtopic = $parameters["clubtopic"];
         $clubname = $parameters["clubs"];
         $noun = $parameters["noun"];
              
        if($departmentassociation == "programs offered"){
          $searchdocument = array();
          $searchdocument["majors"] = $noun;
          $newQuery = array("majors" => $noun);
          $cursor = $collection->find($newQuery);
          $document = $cursor->getNext();
          
          $response = "The programs offered are " .$document["majors"]. ".";
          }

      
//        elseif($departmentassociation == "clubs"){
//          $collection = $db->clubs;
//          $searchdocument = array();
//          $searchdocument["title"] = $club;
//          $newQuery = array("title" => $club);
//          $cursor = $collection->find($newQuery);
//          $document = $cursor->getNext();
         
//          $response = "A club that relates to that topic is " .$document["clubName"]. ".";
//        }//clubs
    
//     elseif($departmentassociation == "clubs"){
//       $collection = $db->clubs;
//       $searchdocument = array();
//       $searchdocument["title"] = $activity;
//       $newQuery = array("title" => $club);
//       $cursor = $collection->find($newQuery);
//       $document = $cursor->getNext();
//                if($cursor->hasNext()){

//       $response = "The clubs the CIS department offer are " .$document["clubName"];
               
//                       while($cursor->hasNext()){
                        
//                         $document = $cursor->getNext();
                        
//                         if(!($cursor->hasNext()))  
                        
//                           $response .= " and ".$document["clubName"]. ".";
                     
//                         else
                           
//                        $response .= ", ".$document["clubName"];                        
                       
//                       }
//                }
//                   else{
//                        $response = "The only club the department offers at the moment is " .$document["clubName"];
//                       }
//                }//elseif
      
    
//     elseif($departmentassociation == "age"){
//       $collection = $db->department;
//       $searchdocument = array();
//       $searchdocument["age"] = $departmentassociation;
//       $newQuery = array("age" => $departmentassociation);
//       $cursor = $collection->find($newQuery);
//       $document = $cursor->getNext();
      
//       $response = "The CIS department is " .$document["age"]. " years old.";
//     }//elseif
      
    
  }//end of department case
    break;
         case "searchservices":{
        $services = $parameters["services"];
        
        $collection = $db->services;
        
        if($services == "digital signage"){
         $newQuery = array("srvName" => $services);
         $cursor = $collection->find($newQuery);
         $document = $cursor->getNext();
          
         $response = "You need to see " .$document["srvAdmin"]. " about that, and they are located in room " .$document["srvLocation"]. ".";; 

          
        }// end of digital signage
        
        elseif($services == "advisement"){
         $searchdocument = array();
         $searhdocument["srvName"] = $services;
          
         $newQuery = array("srvName" => $services);
         $cursor = $collection->find($newQuery);
         $document = $cursor->getNext();

         $response = "The advisor is " .$document["srvName"]. "located in room " .$document["srvLocation"]. ".";
            
            
                      
        }// end of advisement  
        elseif($services == "class override"){
            $searchdocument = array();
            $searhdocument["srvName"] = $services;
            $newQuery = array("srvName" => $services);
            $cursor = $collection->find($newQuery);

            $document = $cursor->getNext();
            $response = "The person you should see about that is " .$document["srvAdmin"]. " and they are located in room " .$document["srvLocation"]. ".";

            
                        
        }//end of class override
        elseif($services == "account"){
            $searchdocument = array();
           $searchdocument["srvName"] = $services;

            $newQuery = array("srvName" => $services);
            $cursor = $collection->find($newQuery);

            $document = $cursor->getNext();
            $response = "The person you should see about that is " .$document["srvAdmin"]. " and they are located in room " .$document["srvLocation"]. ".";

                              
        }//end of account
        elseif($services == "apply for graduation"){
            $searchdocument = array();
            $searchdocument["srvName"] = $services;
            $newQuery = array("srvName" => $services);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();
            $response = "The person you should see about that is " .$document["srvAdmin"]. " and they are located in room " .$document["srvLocation"]. ".";
           
         } 
         elseif($services = "class excuse"){
            $searchdocument = array();
            $searchdocument["srvName"] = $services;
            $newQuery = array("srvName" => $services);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();
            $response = "The person you should see about that is " .$document["srvAdmin"]. " and they are located in room " .$document["srvLocation"]. ".";
           
         }    
         }//endofsearchservices
     break;
    case "peopleamount":{
           if($departmentassociation == "student amount"){
           $searchdocument = array();
           $searchdocument["student amount"] = $department;
           $collection = $db->department;
           $newQuery = array("student amount" => $department);
           $cursor = $collection->find($newQuery);
           $document = $cursor->getNext();
          
           $response = "There are ".$document["student amount"]."students in the department.";
        }
       
    if($departmentassociation == "faculty amount"){
//            $collection = $db->faculty;
      
           $document = $db ->faculty ->count();
      
           $response = "There are " .$document. " faculty in the CIS department.";
    }//elseif
     $response = "There are faculty in the CIS department.";
                                                                                                                                         
    }break;    
    
 
                                                                                                                                                                                                                                                            

  case "whois-intent":{
  $collection = $db->faculty;
  $people = $parameters["people"];
  
  if($people == "professor"){
    $searchdocument = array();
    $searchdocument["title"] = "Associate Professor";
    $newQuery = array("title" => "Associate Professor");
    $cursor = $collection->find();
    $document = $cursor->getNext;
    
        if($cursor->hasNext())
        {
    $response = "The Associate Professors are " .$document["name"];
                    while($cursor->hasNext())
                    {

                        $document = $cursor->getNext();

                         if(!($cursor->hasNext()))
                            $response .= " and ".$document["name"]. "and ";
                        else 
                            $response .= ", ".$document["name"];                        
                         
                    }
          
        }
        else
        {
             $response = "The only Associate Professor at this moment is ".$document["name"]."and ";
          
        }
    
    $searchdocument = array();
    $searchdocument["title"] = "Visting Instructor";
    $newQuery = array("title" => "Visting Instructor");
    $cursor = $collection->find($newQuery);
    $document = $cursor->getNext;

     if($cursor->hasNext())
     {
    $response .= "the Visiting Instructors are " .$document["name"];
                    while($cursor->hasNext())
                    {
                       
                         $document = $cursor->getNext();

                      if(!($cursor->hasNext()))
                            $response .= " and ".$document["name"]. "and ";
                      else
                            $response .= ", ".$document["name"];                        
                        
                    }
     }
    else
    {
             $response .= "the only Visiting Instructor at this moment is ".$document["name"]."and ";
      
    }
  }
  
  elseif($people == "faculty"){
    $cursor = $collection->find();
    $document = $cursor->getNext;
    
    if($cursor->hasNext())
    {
    $response = "The faculty are as follows... " .$document["name"]. ", " .$document["title"];
     while($cursor->hasNext())
     {

                         $document = $cursor->getNext();

                             if(!($cursor->hasNext()))
                            $response .= " and ".$document["name"]. " " .$document["title"]. "and ";
                      else
                            $response .= ", ".$document["name"]. " " .$document["title"];                        

     }//while
    }//if
    else
    {
         $response .= "The only faculty at this moment is ".$document["name"]. ", " .$document["title"];

    }//else
  }//elseif
 
}//whois-intent
 break;

case "facultyinfo-intent":{
  
  $collection = $db->faculty;
  $faculty = $parameters["faculty"];
  
  $searchdocument = array();
  $searchdocument["name"] = $faculty;
  $newQuery = array("name" => $faculty);
  $cursor = $collection->find();
  $document = $cursor->getNext();
  
  $response = $faculty. " is a " .$document["title"]. " here in FAMU's CIS department.";
}
break;

case "addactivity":{
  $collection = $db->login;
  $username = $parameters["username"];
  $password = $parameters["password"];
  
  $searchdocument = array();
  $searchdocument["username"] = $username;
  $newQuery = array("username" => $username);
  $cursor = $collection->find();
  $document = $cursor->getNext;
 
 
  if($password == $document["password"])
  {
   
  $collection = $db->activities;
  $name = $parameters["name"];
  $date = $parameters["date"];
  $time = $parameters["time"];
  $description  = $parameters["description"];
   
   $apptdate = date_format($date, "m/d/Y");
    
   $document = array(
   "name" => $name,
   "date" => $apptdate,
   "time" => $time,
   "description" => $description,
   "title" => "event"  
   );
    
    $collection->insert($document);
    
    $response = "Your activity has been added.";
    
  }
  else
    $response .= "Your activity could not be added. Invalid username or password";
}
break;

//      case "scheduleappointment":{
//         $faculty = $parameters["faculty"];
//         $date = $parameters["date"];
//         $time = $parameters["time"];
//         $name = $parameters["name"];

//         $apptdate = date_format($date, "mm/dd/YY");

//         $document = array(
//                 "faculty" => $faculty,
//                 "date" => $apptdate,
//                 "time" => $time,
//                 "name" => $name
//             );

//           $cursor = $collection->find($document);
//          if($cursor = null){
//              $collection->insert($document);
//              $response = "Your appointment with" .$faculty." is on" .$apptdate." at" .$time;
//          }//if
//          else
//          {
//              $response = .$faculty. " already has an appointment try scheduling a different appointment";
//          }//else
 
//  }//scheduleappointment case

  
 
        
                                                                                                                           
                                                                                                                                       
    default: {$response = "Not currently a case for action";} break;
}//switch

$output["speech"] = $response;
$output["displayText"] = $response;
$output["source"] = "getevents.php";


// //used to test php code
// $output["speech"] = "hello";
// $output["displayText"] = "hello";
// $output["source"] = "orderfood1.php";


ob_end_clean();
echo json_encode($output);
?>