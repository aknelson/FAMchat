<html>
<body>
I will add the 3 numbers
 <br>
<?php 
$a = $_POST["n1"];
$b = $_POST["n2"];
$c = $_POST["n3"];

$sum = $a + $b + $c;

echo "The sum is ".$sum;
    
?>

</body>
</html>