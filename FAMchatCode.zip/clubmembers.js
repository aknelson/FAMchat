db.clubmembers.remove({})

db.clubmembers.insert({"clubName": null, "firstName": null, "lastName": null, "email": null, "classification": null})
db.clubmembers.insert({"clubName": null, "firstName": null, "lastName": null, "email": null, "classification": null})
db.clubmembers.insert({"clubName": null, "firstName": null, "lastName": null, "email": null, "classification": null})
db.clubmembers.insert({"clubName": null, "firstName": null, "lastName": null, "email": null, "classification": null})
db.clubmembers.insert({"clubName": null, "firstName": null, "lastName": null, "email": null, "classification": null})
