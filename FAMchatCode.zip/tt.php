<html>

<head>

<title> My PHP Page</title>

</head>

<body>

<?php echo '<p>Hello Peeps</p>';

for($x=25; $x<=185; $x++)

{

if($x<185)

  {

  echo "$x-";

}

else

  {

echo  "$x" . "/n"

  }

}

?>

</body>

</html>