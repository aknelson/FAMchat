db.order.remove({})

db.order.insert({
  "item" : "hamburger",
  "toppings": "cheese"
})


db.order.insert({
  "item" : "hamburger",
  "toppings": "mustard"
})



