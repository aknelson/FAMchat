db.clubs.remove({})

db.clubs.insert({"title": "club", "clubName":"CISMO", "President": "Kevin Green", "clubTopic": ["mentoring","tutoring"]})
db.clubs.insert({"title": "club", "clubName":"ACM", "President": "Chante White", "clubTopic": ["computing","scientific computing","career development","professional development"]})
db.clubs.insert({"title": "club", "clubName":"ACM-W", "President": "Chante White", "clubTopic": ["computing","scientific computing","career development","professional networking"]})
db.clubs.insert({"title": "club", "clubName":"Secure Rattlers", "President": "Brandon Williams", "clubTopic": ["cyber securtiy","securtiy", "hacking"]})
db.clubs.insert({"title": "club", "clubName":"Video Game Club", "President": "Auburn Jones", "clubTopic": ["gaming", "video games", "game development"]})
