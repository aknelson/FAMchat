db.scholarships.remove({})

db.scholarships.insert({"name" : "Intel Scholarship", 
                        "sponser" : "Intel",
                        "min GPA" : 3.00,
                        "due date" : "10/01/2017",
                        "title" : "scholarships"})
