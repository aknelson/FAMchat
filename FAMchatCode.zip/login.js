db.login.remove({});

db.login.insert({"fname":"John", "lname":"Doe", "username":"abc", "password":"abc", "type":"admin", "title": "account"});
db.login.insert({"fname":"Jane", "lname":"Doe", "username":"xyz", "password":"xyz", "type":"faculty", "title" : "account"});