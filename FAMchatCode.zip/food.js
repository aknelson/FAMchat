db.food.remove({})

db.food.insert({
  "item" : "hamburger",
  "price" : 4
})

db.food.insert({
  "item" : "hotdog",
  "price" : 3
})

db.food.insert({
  "item" : "cookie",
  "price" : 2
})
