db.internships.remove({})

db.internships.insert({"company" : "Eli Lilly",
                       "classifications" : "all",
                       "min GPA" : 3.00,
                       "due date" : "10/13/17",
                       "title" : "internship"})
db.internships.insert({"company" : "Ford",
                       "classifications" : "all",
                       "min GPA" : 3.00,
                       "due date" : "10/23/17",
                       "title" : "internship"})