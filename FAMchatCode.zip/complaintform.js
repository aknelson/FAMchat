db.complaintform.remove({})

db.complaintform.insert({"firstname": null, "lastname": null, "faculty": null, "classification": null, "term": null, "areaofconcern": null, "description": null, "attempttoresolve": null});
