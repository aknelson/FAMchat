db.department.remove({})

db.department.insert({"location" : "http://www.famu.edu/index.cfm?cst&DepartmentofComputerandInformationSciences",
                      "address": {"street" : "Wanish Way", "number" : 1333, "city": "Tallahassee", "state" : "FL", "zip": 32307},
                                  "student amount" : 256,
                                  "majors" : "computer science, information technology, computer information systems",
                                  "lab hours" : "monday - 8am to 10pm, tuesday - 8am to 10pm, wednesday - 8am to 10pm, thursday - 8am to 10pm, friday - 8am to 5pm, saturday - closed, sunday - closed",
                                  "age" : 50
                     })