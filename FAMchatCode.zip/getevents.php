<?php
header('Content-Type: application/json');
ob_start();

$json = file_get_contents('php://input'); 
$request = json_decode($json, true);
$action = $request["result"]["action"];
$parameters = $request["result"]["parameters"];
$activities = $parameters["activities"];
$department = $parameters["department"];
$courses = $parameters["courses"];
$services = $parameters["services"];
$faculty = $parameters["faculty"];
$noun = $parameters["noun"];
$query = $request["result"]["resolvedQuery"];


//connect to mongodb
  $m = new MongoClient();
//echo "Connection to database successfully";
   
     
//select a database
  $db = $m->mydb;

switch($action){
        
    case "department-intent": {
        switch($noun){
            case "where": {
                $searchdocument = array();

                $searchdocument["location"] = $department;
                
                
                $collection = $db->department;
                //echo "Collection selected succsessfully";
  
                $newQuery = array('address.street' => 'Wanish Way');

                $cursor = $collection->find($newQuery);
                 //iterate cursor to display title of documents
     
  
                $document = $cursor->getNext();
                
  
                $response = "The address is ".$document["address"]["street"]." ".$document["address"]["number"]"."; 
  
                $collection = $db->query;
                $document = array( 
                                  "query" => $query
                                 );
                $collection->insert($document);
            }break;//case-where
            case "what": {
              switch($department)
              {
                case "address":
                {  
                $searchdocument = array();

                $searchdocument["location"] = $department;
                
                
                $collection = $db->department;
                //echo "Collection selected succsessfully";
  
                $newQuery = array('address.street' => 'Wanish Way');

                $cursor = $collection->find($newQuery);
                 //iterate cursor to display title of documents
     
  
                $document = $cursor->getNext();
                
  
                $response = "The address is ".$document["address"]["street"]." ".$document["address"]["number"]."."; 
  
                $collection = $db->query;
                $document = array( 
                                  "query" => $query
                                 );
                $collection->insert($document);
                }break;//location
              }//switch department
            }break;//what
        }//switch
     }break;//case department-intent
         
 

    case "getfacultyhours":{
        
       $searchdocument = array();

       $searchdocument["hours"] = $faculty;   
      
        $collection = $db->faculty;
        //echo "Collection selected succsessfully";
  
        $cursor = $collection->find($searchdocument);
        // iterate cursor to display title of documents
  
        $document = $cursor->getNext();
  
  
        $response = "This is".$faculty." is $".$document["hours"];
  
        $collection = $db->query;
        $document = array( 
           "query" => $query
                         );
        $collection->insert($document);

  
     } break;
    case "getlabhours":
    {
 
      //$response="here is the price";

        $searchdocument = array();

        $searchdocument["lab hours"] = $department;   
      

      //echo "Database test selected";
        $collection = $db->department;
      //echo "Collection selected succsessfully";
    
        $newQuery = array('address.street' => 'Wanish Way');

        $cursor = $collection->find($newQuery);
      //iterate cursor to display title of documents
     
  
        $document = $cursor->getNext();

  
        $response = "The ".$department." are ".$document["lab hours"]; 
  
    }break;
    case "findClass": 
    {
        $searchdocument = array();

        $searchdocument["crsID"] = $courses;   
  

     //echo "Database mydb selected";
        $collection = $db->courses;
     //echo "Collection selected succsessfully";

        $newQuery = array("crsID" => $courses);
        $cursor = $collection->find($newQuery);
  

        $document = $cursor->getNext();
 
        if($cursor->hasNext())
           {
                    while($cursor->hasNext())
                    {
                        $response = "The instructors are Professor ".$document["crsInstructor"];
                        
                        $document = $cursor->getNext();
                        
                        if(!($cursor->hasNext()))  
                            $response .= " and Professor ".$document["crsInstructor"];
                        else 
                            $response .= ", ".$document["crsInstructor"];
                        
                    } 
           }
        else
           {
             $response = "The instructor is Professor ".$document["crsInstructor"];
           }

		    
    }break;
    case "findEvents":
    {
     //$response="here is the price";

        $searchdocument = array();

        $searchdocument["title"] = $activities;   
  
        
        $collection = $db->activities;
     //echo "Collection selected succsessfully";

        $newQuery = array("title" => $activities);
        $cursor = $collection->find($newQuery);
     
     //get first event
        $document = $cursor->getNext();
     
        if($cursor->hasNext())
           {
                    while($cursor->hasNext())
                    {
                        $response = "The events are ".$document["name"];
                        
                        $document = $curs
    default: {$response = "Not currently a case for action";} break;
}//switch

$output["speech"] = $response;
$output["displayText"] = $response;
$output["source"] = "getevents.php";


/*
$output["speech"] = "hello";
$output["displayText"] = "hello";
$output["source"] = "orderfood1.php";
*/

ob_end_clean();
echo json_encode($output);
?>

