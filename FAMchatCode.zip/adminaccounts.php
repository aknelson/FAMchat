<html>
<head>
<link rel="stylesheet" href="famchat.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
</head>
  
<Title>Admin Home</Title>
<center><h1 style="color: #056f05; background-color:Orange;">FAMCHAT</h1></center>
<br>
<center><body style="color: Orange; background-color:#056f05;">
    
    <?php

   // connect to mongodb
   $m = new MongoClient();
   // echo "Connection to database successfully";

   // select a database
   $db = $m->mydb;
   //echo "Database mydb selected";
   $collection = $db->login;
   //echo "Collection selected succsessfully";

   $newQuery = array("title" => "account");
   $cursor = $collection->find($newQuery);
 
  
           echo "<table border='4' class='stats' cellspacing='0'>

            <tr>
            <td class='hed' colspan='8'>LIST OF ACCOUNTS</td>
              </tr>
            <tr>
            <th>FIRSTNAME</th>
            <th>LASTNAME</th>
            <th>USERNAME</th>
            <th>PASSWORD</th>
            <th>TYPE</th>

            </tr>";
    
   while($cursor->hasNext())
   {
			$document = $cursor->getNext();

              echo "<tr>";
              echo "<td>" . $document["fname"] . "</td>";
              echo "<td>" . $document["lname"] . "</td>";
              echo "<td>" . $document["username"] . "</td>";
              echo "<td>" . $document["password"] . "</td>";
              echo "<td>" . $document["type"] . "</td>";
    
              echo "</tr>";
   }


    echo "</table>";

?>

  
  </body><center>
</html>