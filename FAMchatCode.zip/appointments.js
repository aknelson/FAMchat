db.appointments.remove({});

db.appointments.insert({"faculty": null, "week":{"monday":null,"tuesday": null, "wednesday": null, "thursday": null, "friday", null}});

