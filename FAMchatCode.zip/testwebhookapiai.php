<?php
header('Content-Type: application/json');

$json = file_get_contents('php://input'); 
$request = json_decode($json, true);
$action = $request["result"]["action"];
$parameters = $request["result"]["parameters"];

$output["speech"] = "Today in Boston: Fair, the temperature is 37 F";
$output["displayText"] = "displayText"." action:".$action." ".$parameters["food"];
$output["source"] = "whatever.php";

echo json_encode($output);

?>