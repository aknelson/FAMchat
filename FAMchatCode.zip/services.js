db.services.remove({});

db.services.insert({"srvName":"advisment", "srvLocation":211, "srvAdmin":"Julia Jones"});
db.services.insert({"srvName":"account", "srvLocation":108, "srvAdmin":"Doug McDonald"});
db.services.insert({"srvName":"class override", "srvLocation":302, "srvAdmin":"Ed Jones"});
db.services.insert({"srvName":"digital signage","srvLocation":211, "srvAdmin":"Julia Jones"});
db.services.insert({"srvName":"apply for graduation","srvLocation":211, "srvAdmin":"Julia Jones"});
db.services.insert({"srvName":"class excuse","srvLocation":105, "srvAdmin":"Dean Office of College of Science and Technology (The University Commons)"});