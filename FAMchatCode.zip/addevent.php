<html>
<body>
  
<?php
$name = $_POST['Event'];
$day = $_POST['Day'];
$time = $_POST['Time'];
$description = $_POST['Information'];


// connnect to mongodb
$m = new MongoClient();


// select a database
$db = $m->mydb;

$collection = $db->activities;

$document = array(
       "name" => $name, 
       "date" => $date,
       "time" => $time,
       "description" => $description,
       "title" => "event"
       
);

$collection->insert($document);
 
$searchdocument = array();
  
if($searchdocument["name"] = $name)
{
echo "Event added successfully";
}
else 
echo "name,date,time, and description all have to be filled in";
?>
</body>
</html>
