db.activities.remove({})

db.activities.insert({"name": "Eli Lilly Informational" ,"date": "October 24th ,2017","time": "1:30 pm","description": "Employees of Eli Lilly will be answering questions about the company", "title":"events"})

db.activities.insert({"name": "Secured Rattlers GBM" ,"date": "October 30th, 2017" ,"time": "5:00 pm" ,"description": "A meeting for all general members to discuss the next competition", "title":"events"})

db.activities.insert({"name": "Ford Interviews" ,"date":"November 1st, 2017" ,"time": "2:30 pm" ,"description": "A team of Ford employees will be here to conduct interviews for employment and internships", "title":"events"})