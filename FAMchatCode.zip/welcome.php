<html>
<body>

Welcome <?php echo $_POST["personname"]; ?><br>
Your email address is: <?php echo $_POST["emailaddress"]; ?>

</body>
</html>