<?php
header('Content-Type: application/json');
ob_start();

$json = file_get_contents('php://input'); 
$request = json_decode($json, true);
$action = $request["result"]["action"];
$parameters = $request["result"]["parameters"];
/*
$activities = $parameters["activities"];
$department = $parameters["department"];

$services = $parameters["services"];

$query = $request["result"]["resolvedQuery"];


$date = $parameters["date"];
$time = $parameters["time"];

$term = $parameters["term"];
$areaofconcern = $parameters["areaofconcern"];
$description = $parameters["description"];
$attempttoresolve = $parameters["attempttoresolve"];

*/

  // connect to mongodb
   $m = new MongoClient();

   // select a database
   $db = $m->mydb;

switch($action) {
    
    // in join-club intent
  /*  case "joinclub":{ 
    $clubname = $parameters["clubname"];
    $firstname = $parameters["firstname"];
    $lastname = $parameters["lastname"];
    $email = $parameters["email"];
    $classification = $parameters["classification"];
       
       //select collection
        $collection = $db->clubmembers;

        //create a document
        $document = array(
           "clubName" => $clubname, 
           "FirstName" => $firstname,
           "LastName" => $lastname,
           "classification" => $classification,
           "email" => $email
        );

       //insert document
       $collection->insert($document);

        $searchdocument = array();
        if($searchdocument["firstName"] = $firstname && $searchdocument["clubName"] = $clubname)
           $response = "You have been added to $clubname succesfully.";
        else
           $response = "Lets try again";
    }//end of join club case
        
    break;
 */
    // in courses intent
    case "findClass":{
        $courses = $parameters["courses"]; 
        $noun = $parameters["noun"];    
        $courseassociation = $parameters["courseassociation"];       
        $topic = $parameters["topic"];        
        
        $searchdocument = array();
        //select collection
        $collection = $db->courses;

         // user asks what are the credit hours 
        if($courseassociation == "credit hours"){
           //$searchdocument["crsHrs"] = $courses;

            $newQuery = array("crsID" => $courses);
            $cursor = $collection->find($newQuery);

            $document = $cursor->getNext();
            $response = "The course" .$courses. " is " .$document["crsHrs"]. " credit hours";

        } 
        // user asks what are the prereqs
        elseif($courseassociation == "prerequisities"){
          //  $searchdocument["crsID"] = $courses;
            $newQuery = array("crsID" => $courses);
            $cursor = $collection->find($newQuery);    
            $document = var_dump($cursor->getNext());
            
            $response = "The prerequisities for " .$courses." are" .$document["prereqs"]. ".";

        }
            /*
        // user asks does a class teach a topic
        elseif($courseassociation == "teaches" ){
           // $searchdocument["crstopic"] = $topic;
            $newQuery = array("crsTopic" => $topic);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();
          
           if($cursor->hasNext())
           {
                     $response = "A course that teaches that topic is " .$document["crsID"]. "."; 
                    while($cursor->hasNext())
                    {
                        
                        $document = $cursor->getNext();
                        
                        if(!($cursor->hasNext()))  
                            $response .= " and ".$document["crsID"]. ".";
                        else 
                            $response .= ", ".$document["crsID"]. ".";            
        } */
            
        //user asks is class taught
        if($noun == "Is"){
            $searchdocument["crsID"] = $courses;
            $newQuery = array("crsID" => $courses);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();
             if($cursor = $collection->find(array("crsID" => null))){
                $response = "Yes";
            } else{
                $response = "No";
            } 

        } 
    }// end of find class case
    break;
     /*
// in scheduleappointment intent
    case "scheduleappointment":{

        $document = array(
                "faculty" => $faculty,
                "date" => $date,
                "time" => $time
            );
    
          $cursor = $collection->find($document);
         if(cursor == null){
             $collection->insert($document);
             $response = "Your appointment with" .$faculty." on" .$date." at" .$time;
         }else{
             $response = .$faculty. " already has an appointment try scheduling a different appointment";
         }
    }// end of schedule appointment case
        break;

  
   /* puts query into a database
   $collection = $db->query;
   $document = array( 
           "query" => $query
     );
   $collection->insert($document);
   */


    case "people":{
        $faculty = $parameters["faculty"];
        $noun = $parameters["noun"];
        $facultyassociation = $parameters["facultyassociation"];        
        $collection = $db->faculty;

        //user asks who is the chairman
        if($facultyassociation == "Chairperson"){
      //      $searchdocument["title"] = $facultyassociation;
            $newQuery = array("title" => $facultyassociation);
            $cursor = $collection->find($newQuery);      
            $document = $cursor->getNext();

            $response = "The chairperson is " .$document["name"];

        }
          
          //user asks who are the systems administartors
        elseif($facultyassociation == "System Administrator"){
    //         $searchdocument["title"] = $facultyassociation;
            $newQuery = array("title" => $facultyassociation);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();   

         if($cursor->hasNext())
           {
                     $response = "The system's administrators are " .$document["name"]. "."; 
                    while($cursor->hasNext())
                    {
//                         $response = "The system's administrators are " .$document["name"]; 
                        
                        $document = $cursor->getNext();
                        
                        if(!($cursor->hasNext()))  
                            $response .= " and ".$document["name"]. "";
                        else 
                            $response .= ", ".$document["name"]. "";                        
                    } 
           }
        else
           {
             $response = "The system's administrators is " .$document["name"]. ""; 
           }


        }//user asks who is the secretary or office manager
        elseif($facultyassociation == "Office Manager"){
    //        $searchdocument["title"] = $facultyassociation;
            $newQuery = array("title" => $facultyassociation);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();      
            $response = "The secretary is ".$document["name"]. "";
        }

        //user asks where is someones office
        if($noun == "where"){
    //         $searchdocument["name"] = $faculty;
            $newQuery = array("name" => $faculty);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();
            $response = $faculty."'s office is ".$document["location"]. "";

//          user asks what is someones research
        }elseif($facultyassociation == "research"){
          //  $searchdocument["name"] = $faculty;
            $newQuery = array("name" => $faculty);
            $cursor = $collection->find($newQuery);
            $document = $cursor->getNext();

            $response = $faculty."'s research is ".$document["research"]. "";    
        } 
    }//end of people case
        break;
   /*
    case "academiccomplaint":{
    
        $document = array(
            "firstname" => $firstname,
            "lastname" => $lastname,
            "faculty" => $faculty,
            "classification" => $classification,
            "term" => $term,
            "areaofconcern" => $areaofconcern,
            "description" => $description,
            "attempttoresolve" => $attempttoresolve
            );
    
           $collection->insert($document);

           $response = "Your academic complaint has been added.";
            
    }//end of academic complaint case
      break;
     */
        
    default: {$response = "Not currently a case for action";} break;
}//switch 

$output["speech"] = $response;
$output["displayText"] = $response;
$output["source"] = "courses.php";

ob_end_clean();
echo json_encode($output);

?>