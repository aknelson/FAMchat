
case "whois-intent":{
  $collection = $db->faculty;
  
  if($noun == "professor"){
    $searchdocument = array();
    $searchdocument["title"] = "Associate Professor";
    $newQuery = array("title" => "Associate Professor");
    $cursor = $collection->find();
    $document = $cursor->getNext;
    
        if($cursor->hasNext())
        {
    $response = "The Associate Professors are " .$document["name"];
                    while($cursor->hasNext())
                    {
                        $response = "The Associate Professors are ".$document["name"];

                        $document = $cursor->getNext();

                         if(!($cursor->hasNext()))
                            $response .= " and ".$document["name"]. "and ";
                        else 
                            $response .= ", ".$document["name"];                        
                         
                    }
          
        }
        else
        {
             $response = "The only Associate Professor at this moment is ".$document["name"]."and ";
          
        }
    
    $searchdocument = array();
    $searchdocument["title"] = "Visting Instructor";
    $newQuery = array("title" => "Visting Instructor");
    $cursor = $collection->find($newQuery);
    $document = $cursor->getNext;

     if($cursor->hasNext())
     {
    $response .= "the Visiting Instructors are " .$document["name"];
                    while($cursor->hasNext())
                    {
                         $response .= "the Visitng Instructors are ".$document["name"];
                       
                         $document = $cursor->getNext();

                      if(!($cursor->hasNext()))
                            $response .= " and ".$document["name"]. "and ";
                      else
                            $response .= ", ".$document["name"];                        
                        
                    }
     }
    else
    {
             $response .= "the only Visiting Instructor at this moment is ".$document["name"]."and ";
      
    }
  }
  
  if($noun == "faculty"){
    $cursor = $collection->find();
    $document = $cursor->getNext;
    
    if($cursor->hasNext())
    {
    $response = "The faculty are as follows... " .$document["name"]. ", " .$document["title"];
     while($cursor->hasNext())
     {
                         $response .= "the Visitng Instructors are ".$document["name"];

                         $document = $cursor->getNext();

                             if(!($cursor->hasNext()))
                            $response .= " and ".$document["name"]. ", " .$document["title"]. "and ";
                      else
                            $response .= ", ".$document["name"] ", " .$document["title"];                        

     }
    }
    else
    {
         $response .= "The only faculty at this moment is ".$document["name"]. ", " .$document["title"];

    }
  }
 
}//whois-intent
 break;

case "facultyinfo-intent":{
  
  $collection = $db->faculty;
  $faculty = $parameters["faculty"];
  
  $searchdocument = array();
  $searchdocument["name"] = $faculty;
  $newQuery = array("name" => $faculty);
  $cursor = $collection->find();
  $document = $cursor->getNext();
  
  $response = .$faculty. " is a " .$document["title"]. " here in FAMU's CIS department.";
}
break;

case "addactivity":{
  $collection->login;
  $username = $parameters["username"];
  $password = $parameters["password"];
  
  $searchdocument = array();
  $searchdocument["username"] = $username;
  $newQuery = array("username" => $username);
  $cursor = $collection->find();
  $document = $cursor->getNext;
 
  if($password == .$document["password"])
  {
   
  $collection->activities;
  $name = $parameters["activityname"];
  $date = $parameters["date"];
  $time = $parameters["time"];
  $description  = $parameters["description"];
    
   $document = array(
   "name" => $name,
   "date" => $date,
   "time" => $time,
   "description" => $description,
   "title" => "event"  
   );
    
    $collection->insert($document);
    
    $response = "Your activity has been added.";
    
  }
}
break;

