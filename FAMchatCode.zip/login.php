<html>
<body> 
  
<?php

$username = $_POST['Username'];
$password = $_POST['Password'];
  
   $searchdocument = array();

   $searchdocument["username"] = $username;   
    
  // connect to mongodb
   $m = new MongoClient();
  // echo "Connection to database successfully";

   // select a database
   $db = $m->mydb;
   //echo "Database mydb selected";
   $collection = $db->login;
  
   $cursor = $collection->find($searchdocument);
   // iterate cursor to display title of documents
  
   $document = $cursor->getNext();

  //echo "Collection selected succsessfully";
    
    if($document["username"] == $username & $document["password"] == $password)
    {
      $_SESSION["username"]= $username;
      $_SESSION["password"]= $password;
      $_SESSION["type"]= $document["type"];
      header("location: home.html");
      
      if($document["type"] == "admin")
        header("location: admin.html");
      elseif($document["type"] == "faculty")
        header("location: faculty.html");
    }
    else

      echo "Username and/or Password is incorrect";
  
  


?>
</body> 
</html>
