<?php
header('Content-Type: application/json');
ob_start();

$json = file_get_contents('php://input'); 
$request = json_decode($json, true);
$action = $request["result"]["action"];
$parameters = $request["result"]["parameters"];
$food = $parameters["food"];
$toppings = $parameters["toppings"];
$query = $request["result"]["resolvedQuery"];

if( $action == "orderoneitem" ) {


if($food == "hamburger") $response = "You want a ".$food." That will be $5";
else if($food == "hotdog") $response = "You want a ".$food." That will be $3";
else if($food == "cookie") $response = "You want a ".$food." That will be $2";
else $response = "I do not understand your order. We have burgers, hotdogs and cookies";
  
  // connect to mongodb
   $m = new MongoClient();
  // echo "Connection to database successfully";
	
   // select a database
   $db = $m->test;
   //echo "Database mydb selected";
   $collection = $db->order;
   //echo "Collection selected succsessfully";
	
   $document = array( 
      "item" => $food, 
      "toppings" => $toppings, 
   );
	
   $collection->insert($document);

} elseif( $action == "getprice" ) {
 
  //$response="here is the price";

      $searchdocument = array();

      $searchdocument["item"] = $food;   
      
   // connect to mongodb
   $m = new MongoClient();
   //echo "Connection to database successfully";
   
     
   // select a database
   $db = $m->test;
   //echo "Database test selected";
   $collection = $db->food;
   //echo "Collection selected succsessfully";
  
   $cursor = $collection->find($searchdocument);
   // iterate cursor to display title of documents
  
  $document = $cursor->getNext();
  
  $response = "A ".$food." is $".$document["price"];
  
  $collection = $db->query;
  $document = array( 
       "query" => $query
    );
  $collection->insert($document);

  
}

$output["speech"] = $response;
$output["displayText"] = $response;
$output["source"] = "orderfood1.php";

/*

$output["speech"] = "hello";
$output["displayText"] = "hello";
$output["source"] = "orderfood1.php";
*/
ob_end_clean();
echo json_encode($output);

?>